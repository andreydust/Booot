-- MySQL dump 10.13  Distrib 5.1.41, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: booot
-- ------------------------------------------------------
-- Server version	5.1.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bt_admin_users`
--

DROP TABLE IF EXISTS `bt_admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) NOT NULL,
  `password` varchar(128) NOT NULL,
  `type` enum('a','m') NOT NULL DEFAULT 'm',
  `access` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `email` varchar(128) NOT NULL,
  `lastenter` datetime NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_admin_users`
--

LOCK TABLES `bt_admin_users` WRITE;
/*!40000 ALTER TABLE `bt_admin_users` DISABLE KEYS */;
INSERT INTO `bt_admin_users` VALUES (1,'admin','admin','a','','','Администратор','andreydust@gmail.com','2011-02-04 12:07:49','2010-12-15 11:44:56','2011-02-03 17:21:41');
/*!40000 ALTER TABLE `bt_admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_blocks`
--

DROP TABLE IF EXISTS `bt_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `callname` varchar(128) NOT NULL,
  `show` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `callname` (`callname`),
  KEY `show` (`show`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_blocks`
--

LOCK TABLES `bt_blocks` WRITE;
/*!40000 ALTER TABLE `bt_blocks` DISABLE KEYS */;
INSERT INTO `bt_blocks` VALUES (1,0,'Текст под логотипом','sub_logo','Y','N','2010-12-15 16:32:25','2011-02-03 20:16:54','Техника и электроника'),(2,0,'Телефон','phone','Y','N','2010-12-15 16:32:46','2011-02-03 20:17:14','(343) 222-22-22'),(3,0,'icq','icq','Y','N','2010-12-15 16:33:06','2010-12-15 17:14:07','14859482'),(4,0,'skype','skype','Y','N','2010-12-15 16:33:47','0000-00-00 00:00:00','andreydust'),(5,0,'Текст на главной','main_text','Y','N','2010-12-15 16:37:40','2011-02-03 20:18:14','Компания «Booot.ru» — официальный дилер крупнейших мировых производителей техники и электроники.'),(7,0,'Адрес','address','Y','N','2010-12-15 16:40:50','2011-02-03 20:19:39','620075, г. Екатеринбург, 3я улица строителей, д. 25, кв. 12'),(8,0,'О компании в футере (внизу)','about_footer','Y','N','2010-12-15 16:42:28','2011-02-03 20:20:43','<p>Интернет-магазин электроника и техника «Booot.ru»: Сотовые, Золото, Семечки, Родина с доставкой по Екатеринбургу.</p>'),(9,0,'Реквизиты в футере (внизу)','details_footer','Y','N','2010-12-15 16:43:50','2011-02-03 20:21:46','<p>ООО «Booot.ru»</p>\r\n<p>ОГРН 1036610974374</p>'),(10,0,'Текст после оформления заказа','basket_thanks','Y','N','2011-02-02 18:48:44','0000-00-00 00:00:00','<p>Наш менеджер скоро свяжется с вами. Пожалуйста, не выключайте телефон некоторое время.</p>');
/*!40000 ALTER TABLE `bt_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_comments`
--

DROP TABLE IF EXISTS `bt_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `hash` char(32) NOT NULL,
  `author` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `text` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_comments`
--

LOCK TABLES `bt_comments` WRITE;
/*!40000 ALTER TABLE `bt_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `bt_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_content`
--

DROP TABLE IF EXISTS `bt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `top` int(10) unsigned NOT NULL,
  `order` int(10) NOT NULL,
  `nav` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `module` varchar(32) NOT NULL,
  `template` varchar(63) NOT NULL DEFAULT 'page.php',
  `showmenu` enum('Y','N') NOT NULL DEFAULT 'N',
  `show` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_content`
--

LOCK TABLES `bt_content` WRITE;
/*!40000 ALTER TABLE `bt_content` DISABLE KEYS */;
INSERT INTO `bt_content` VALUES (1,0,0,'about-us','О магазине','<p>{form:write-to-us}</p>\r\n<p>{block:details_footer}</p>\r\n<p>{block:address}</p>\r\n<p><strong>{block:phone}</strong></p>\r\n<p>Мы работаем для тех, кто не может себе позволить тратить время на пробки по пути в магазин, на стояние в очередях, на хождение между бесконечными полками с товарами. Мы поможем вам сделать единственно верный выбор, и поможем быстро.</p>','','page.php','Y','Y','N','2010-08-19 16:52:31','2010-09-13 18:36:33'),(2,0,1,'payment','Способы оплаты','<p>Если вы хотите заплатить наличными, это можно сделать при покупке - как в офисе, так и при курьерской доставке. <strong>Оплата принимается в рублях</strong>.</p>\r\n<p><strong>При доставке курьером</strong> вы передаете деньги нашему сотруднику, а он выдает вам товарную накладную и заполняет гарантийный талон. Подписав товарный чек, вы подтверждаете факт оплаты и доставки товара.</p>','','page.php','Y','Y','N','2010-08-19 16:59:43','2010-09-13 18:25:18'),(3,0,2,'delivery','Доставка','<p>По Лондону &ndash; в день заказа или на следующий. Стоимость&nbsp; 40 рублей. При заказах от 800 рублей доставка бесплатна.</p>\r\n<p>В пригороды Лондона &ndash; в день заказа или на следующий. 5 рублей за километр от границ Лондона. Доставка в Исламабад, Днепропетровск, Карачи, Астрахань, Токио и Торонто производится бесплатно.</p>\r\n<p>В города Нигерии в течение 3-4 дней без предоплаты.</p>','','page.php','Y','Y','N','2010-08-19 16:59:59','2010-09-15 16:56:46'),(4,0,6,'catalog','Каталог','','CatalogNano','page.php','N','Y','N','2010-08-19 17:00:36','2011-02-03 17:23:42'),(5,0,7,'basket','Корзина','','Basket','page.php','N','Y','N','2010-08-19 18:10:09','2011-01-25 20:28:58'),(6,4,0,'hi','Привет','','','page.php','N','N','N','2010-09-15 18:37:04','0000-00-00 00:00:00'),(14,3,0,'ekaterinburg','Екатеринбург','','','page.php','Y','Y','N','2010-12-15 14:38:21','2010-12-15 14:38:37'),(15,3,0,'moscow','Москва','','','page.php','Y','Y','N','2010-12-15 14:39:39','0000-00-00 00:00:00'),(16,0,4,'help','Помощь','','','page.php','N','Y','N','2010-12-15 14:40:50','0000-00-00 00:00:00'),(17,16,0,'how-to-buy','Как купить?','','','page.php','Y','Y','N','2010-12-15 14:43:47','2010-12-15 14:43:57'),(18,16,0,'how-to-choose-a-boiler','Как выбрать котел?','','','page.php','Y','Y','N','2010-12-15 14:44:13','2010-12-15 14:44:31'),(19,16,0,'boiler-services','Обслуживание котлов','','','page.php','Y','Y','N','2010-12-15 14:44:24','0000-00-00 00:00:00'),(20,0,3,'news','Новости','','News','page.php','Y','Y','N','2010-12-20 15:56:21','2010-12-20 16:28:31'),(21,0,5,'more','Дополнительно','','','page.php','N','Y','N','2011-01-15 19:09:00','0000-00-00 00:00:00'),(22,21,0,'how-to-choose-a-phone-','Как выбрать телефон?','','','page.php','Y','Y','N','2011-01-15 19:09:39','2011-02-04 10:03:05'),(23,21,0,'how-to-buy-','Как совершить покупку?','','','page.php','Y','Y','N','2011-01-15 19:09:58','0000-00-00 00:00:00'),(24,21,0,'maintenance-technology','Обслуживание техники','','','page.php','Y','Y','N','2011-01-15 19:10:16','2011-02-04 10:03:17'),(25,21,0,'installation-and-assembly-of-boilers','Установка и монтаж котлов','','','page.php','Y','Y','Y','2011-01-15 19:10:26','0000-00-00 00:00:00'),(26,21,0,'water-heaters','Водонагреватели','','','page.php','N','N','Y','2011-01-15 19:10:35','0000-00-00 00:00:00'),(27,0,8,'feedback','Напишите нам','<p>{form:1}</p>','','page.php','N','Y','N','2011-01-17 14:11:05','2011-01-17 14:12:07');
/*!40000 ALTER TABLE `bt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_data`
--

DROP TABLE IF EXISTS `bt_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(64) NOT NULL,
  `data` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_data`
--

LOCK TABLES `bt_data` WRITE;
/*!40000 ALTER TABLE `bt_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `bt_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_forms`
--

DROP TABLE IF EXISTS `bt_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `callname` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `show` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_forms`
--

LOCK TABLES `bt_forms` WRITE;
/*!40000 ALTER TABLE `bt_forms` DISABLE KEYS */;
INSERT INTO `bt_forms` VALUES (1,0,'Напишите нам','write-to-us','andreydust@gmail.com','Y','N','2010-12-16 13:55:25','2010-12-21 16:06:20');
/*!40000 ALTER TABLE `bt_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_forms_fields`
--

DROP TABLE IF EXISTS `bt_forms_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_forms_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form` int(10) unsigned NOT NULL,
  `type` enum('text','textarea','checkbox') NOT NULL DEFAULT 'text',
  `label` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `regex` varchar(255) NOT NULL,
  `regex_error` varchar(255) NOT NULL,
  `default` varchar(255) NOT NULL,
  `required` enum('Y','N') NOT NULL DEFAULT 'N',
  `order` int(11) NOT NULL,
  `show` enum('Y','N') NOT NULL DEFAULT 'Y',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `form` (`form`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_forms_fields`
--

LOCK TABLES `bt_forms_fields` WRITE;
/*!40000 ALTER TABLE `bt_forms_fields` DISABLE KEYS */;
INSERT INTO `bt_forms_fields` VALUES (1,1,'text','Ваше имя','your-name','','','','N',0,'Y','2010-12-16 15:30:38','2011-01-19 09:51:20'),(2,1,'text','Телефон','phone','','','','Y',1,'Y','2010-12-16 15:31:31','2011-01-19 09:51:23'),(3,1,'textarea','Сообщение','message','','','','Y',2,'Y','2010-12-16 15:31:51','2011-01-19 09:51:04'),(4,1,'checkbox','Ответье мне срочно!','answer-me-quickly-','','','','N',3,'Y','2010-12-16 15:57:26','2011-01-19 09:47:44');
/*!40000 ALTER TABLE `bt_forms_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_images`
--

DROP TABLE IF EXISTS `bt_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `src` varchar(255) NOT NULL,
  `md5` varchar(32) NOT NULL,
  `module` varchar(64) NOT NULL,
  `module_id` int(11) NOT NULL,
  `alter_key` varchar(64) NOT NULL,
  `main` enum('Y','N') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_images`
--

LOCK TABLES `bt_images` WRITE;
/*!40000 ALTER TABLE `bt_images` DISABLE KEYS */;
INSERT INTO `bt_images` VALUES (1,'/data/moduleImages/CatalogNano/1/e31a4b2044ec59ad5dd6e06e0bf657d4.jpeg','e31a4b2044ec59ad5dd6e06e0bf657d4','CatalogNano',1,'','Y'),(2,'/data/moduleImages/CatalogNano/1/3d38835cf7d84b4278417fcb8b5f86fa.jpeg','3d38835cf7d84b4278417fcb8b5f86fa','CatalogNano',1,'','N'),(3,'/data/moduleImages/CatalogNano/1/9b5720ddbb209ddd6a3b6cece186c45f.jpeg','9b5720ddbb209ddd6a3b6cece186c45f','CatalogNano',1,'','N'),(4,'/data/moduleImages/CatalogNano/2/33b34c42c68df270c4ae7c8d070fc2a3.jpeg','33b34c42c68df270c4ae7c8d070fc2a3','CatalogNano',2,'','Y'),(5,'/data/moduleImages/CatalogNano/2/797b6da9ab9077221ddd266eabd69156.jpeg','797b6da9ab9077221ddd266eabd69156','CatalogNano',2,'','N'),(6,'/data/moduleImages/CatalogNano/2/566e5bb5750095d2aaf1823ab599c7f0.jpeg','566e5bb5750095d2aaf1823ab599c7f0','CatalogNano',2,'','N'),(7,'/data/moduleImages/CatalogNano/3/ef09f0a8a58bce0f899e6d17c7f0c8ce.jpeg','ef09f0a8a58bce0f899e6d17c7f0c8ce','CatalogNano',3,'','Y'),(8,'/data/moduleImages/CatalogNano/3/fc0cbb8e7554c16cd6b50b95acc91f37.jpeg','fc0cbb8e7554c16cd6b50b95acc91f37','CatalogNano',3,'','N'),(9,'/data/moduleImages/CatalogNano/3/260f16cc6b4b8eb72a0b596517af4252.jpeg','260f16cc6b4b8eb72a0b596517af4252','CatalogNano',3,'','N'),(10,'/data/moduleImages/CatalogNano/3/e5cd2a1c28b013766115228efac61be3.jpeg','e5cd2a1c28b013766115228efac61be3','CatalogNano',3,'','N'),(11,'/data/moduleImages/CatalogNano/4/7767622fe2d275b84a8e04a4313f8723.jpeg','7767622fe2d275b84a8e04a4313f8723','CatalogNano',4,'','Y'),(12,'/data/moduleImages/CatalogNano/4/0a4ca67a7d3e267d1aa320f73c8264c3.jpeg','0a4ca67a7d3e267d1aa320f73c8264c3','CatalogNano',4,'','N'),(13,'/data/moduleImages/CatalogNano/4/58e91a5e155c43d97e80e2750aa23638.jpeg','58e91a5e155c43d97e80e2750aa23638','CatalogNano',4,'','N'),(14,'/data/moduleImages/CatalogNano/4/020421e854d20422fe9fcb78aca39d55.jpeg','020421e854d20422fe9fcb78aca39d55','CatalogNano',4,'','N'),(15,'/data/moduleImages/CatalogNano/5/8d446f2e5a80159bac620a5e7363e0ca.jpg','8d446f2e5a80159bac620a5e7363e0ca','CatalogNano',5,'','Y'),(16,'/data/moduleImages/CatalogNano/6/5d9268104c4a8a388ca02e17e434d077.png','5d9268104c4a8a388ca02e17e434d077','CatalogNano',6,'','Y'),(17,'/data/moduleImages/CatalogNano/7/679c5e294fb9586f8be97e5cc0d74048.png','679c5e294fb9586f8be97e5cc0d74048','CatalogNano',7,'','Y'),(18,'/data/moduleImages/CatalogNano/8/b8b4faff0f4a4f904f4693d9462a31c8.jpg','b8b4faff0f4a4f904f4693d9462a31c8','CatalogNano',8,'','Y'),(19,'/data/moduleImages/CatalogNano/8/65217156603f912b64f77abc6f02402e.jpg','65217156603f912b64f77abc6f02402e','CatalogNano',8,'','N');
/*!40000 ALTER TABLE `bt_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_mediafiles`
--

DROP TABLE IF EXISTS `bt_mediafiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_mediafiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `src` varchar(255) NOT NULL,
  `md5` varchar(32) NOT NULL,
  `filetype` varchar(4) NOT NULL,
  `fileinfo` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `module` varchar(64) NOT NULL,
  `module_id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_mediafiles`
--

LOCK TABLES `bt_mediafiles` WRITE;
/*!40000 ALTER TABLE `bt_mediafiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `bt_mediafiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_news`
--

DROP TABLE IF EXISTS `bt_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `show` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `anons` text NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_news`
--

LOCK TABLES `bt_news` WRITE;
/*!40000 ALTER TABLE `bt_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `bt_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_products`
--

DROP TABLE IF EXISTS `bt_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `top` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nav` varchar(100) NOT NULL,
  `brand` int(11) NOT NULL,
  `price` float(11,2) NOT NULL,
  `date` datetime NOT NULL,
  `show` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `anons` text NOT NULL,
  `text` text NOT NULL,
  `types` longtext NOT NULL,
  `is_action` enum('Y','N') NOT NULL DEFAULT 'N',
  `is_featured` enum('Y','N') NOT NULL DEFAULT 'N',
  `availability` text NOT NULL,
  `relations` varchar(255) NOT NULL,
  `rate` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `show` (`show`),
  KEY `deleted` (`deleted`),
  KEY `top` (`top`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_products`
--

LOCK TABLES `bt_products` WRITE;
/*!40000 ALTER TABLE `bt_products` DISABLE KEYS */;
INSERT INTO `bt_products` VALUES (1,2,0,'Desire HD','HTC-Desire-HD',1,25300.00,'0000-00-00 00:00:00','Y','N','2011-02-03 20:29:55','2011-02-04 09:53:08','Удобнейшая оболочка для ОС HTC Sence, с отличными возможностями персонализации и расширения.','','','N','N','','',2,0),(2,2,0,'N8','Nokia-N8',2,18800.00,'0000-00-00 00:00:00','Y','N','2011-02-04 09:39:15','2011-02-04 09:59:03','Достоинства:\r\n\r\n    * Камера\r\n    * Конструкция\r\n    * Скорость\r\n    * Качество звука\r\n    * Цена\r\n    * Аксессуары\r\n    * Навигация\r\n    * Дизайн\r\n    * Комплектация','','','N','Y','','5',1,0),(3,2,0,'iPhone 4 32Gb','iPhone-4-32Gb',3,42000.00,'0000-00-00 00:00:00','Y','N','2011-02-04 09:41:53','2011-02-04 09:54:01','Достоинства:\r\n\r\n    * Экран\r\n    * Камера\r\n    * Скорость\r\n    * Удобство использования\r\n    * Конструкция\r\n    * Программное обеспечение\r\n    * Качество звука','','','N','Y','','',1,0),(4,2,0,'Legend','Legend',1,16590.00,'0000-00-00 00:00:00','Y','N','2011-02-04 09:44:12','2011-02-04 09:51:52','Достоинства:\r\n\r\n    * Экран\r\n    * Конструкция\r\n    * Программное обеспечение\r\n    * Дизайн\r\n    * Скорость\r\n    * Камера\r\n    * Вес\r\n    * Размер','','','N','Y','','',1,0),(5,3,0,'Стилусы универсальные','',0,40.00,'0000-00-00 00:00:00','Y','N','2011-02-04 09:58:02','2011-02-04 10:01:57','Пачка стилусов для любых телефонов','','','N','Y','','',1,0),(6,5,0,'503 /НкШЗ/ 135/80 R12 шип.','',4,1400.00,'0000-00-00 00:00:00','Y','N','2011-02-04 10:07:31','2011-02-04 10:08:15','','<h3>Функциональные характеристики</h3>\r\n<p><strong><br /></strong><strong>Кама-503 -</strong> бескамерная шипуемая шина с зимним рисунком протектора, насыщенным продольными и поперечными канавками и ножевыми прорезями.<br /><br /><strong>Рисунок протектора</strong><br />Крупные  &laquo;ломаные&raquo; шашки повышают проходимость шины, что важно на заснеженных  дорогах, а крупные канавки позволяют эффективно отводить воду и грязь из  пятна контакта с дорогой.<br /><br /><strong>Управляемость</strong><br />Центральное  ребро жесткости обеспечивает курсовую устойчивость автомобиля и его  управляемость. Заводской способ ошиповки обеспечивает ее отличное  качество и надежность.<br /><br />Для зимних ошипованных шин установлено ограничение максимальной скорости &ndash; 130 км/ч (Межгосударственный ГОСТ 4754-97).</p>','','N','N','','',1,2),(7,5,0,'Nordmaster ST310 K-275 185/70 R14 шип','',5,2000.00,'0000-00-00 00:00:00','Y','N','2011-02-04 10:09:31','0000-00-00 00:00:00','','<h3>Функциональные характеристики</h3>\r\n<p><br /><strong>Повышенная управляемость</strong><br />Зигзагообразные  продольные и поперечные канавки с остроугольными кромками увеличивают  механическое сцепление с дорожным покрытием, способствуют повышению  управляемости, боковой устойчивости.<br /><br /><strong>Проходимость по рыхлому снегу</strong><br />Ребра-грунтозацепы обеспечивают отличную проходимость по рыхлому снегу.<br /><br /><strong>Короткий тормозной путь</strong><br />Все  элементы протектора чрезвычайно насыщены зигзаогообразными ламелями,  что существенно сокращает тормозной путь и время разгона, препятствует  пробуксовке и скольжению.</p>','','N','N','','',1,0),(8,9,0,'Citisport','',6,3670.00,'0000-00-00 00:00:00','Y','N','2011-02-04 10:21:29','0000-00-00 00:00:00','# Ультралегкая и компактная коляска;\r\n# Высококачественная прочная рама;\r\n# Эргономичная ручка, регулируемая по высоте;\r\n# Передние и задние амортизаторы; ','<p>Особенности:</p>\r\n<ul>\r\n<li>Ультралегкая и компактная коляска;</li>\r\n<li>Высококачественная прочная рама;</li>\r\n<li>Эргономичная ручка, регулируемая по высоте;</li>\r\n<li>Передние и задние амортизаторы; </li>\r\n<li>Передние колеса плавающие с фиксатором; </li>\r\n<li>Сверхкомпактная, идеальна для хранения дома или в багажнике;</li>\r\n<li>Простая система складывания позволит Вам сложить коляску одной рукой, даже удерживая ребенка;</li>\r\n<li>Простота маневрирования в ограниченном пространстве и узких проходах;</li>\r\n<li>Удобное мягкое сиденье;</li>\r\n<li>Несколько положений спинки от 100 до 130&deg;;</li>\r\n<li>Тент с проверенной устойчивостью к УФ- лучам для оптимальной защиты от солнца;</li>\r\n<li>Автоматический замок фиксирует коляску в сложенном положении;</li>\r\n<li>Удобная ручка для переноски;</li>\r\n<li>5-точечные ремни безопасности;</li>\r\n<li>Бампер безопасности;</li>\r\n<li>С 6 мес до 3х лет.</li>\r\n</ul>\r\n<p>В комплект входит:</p>\r\n<ul>\r\n<li>Вместительная корзина для покупок.</li>\r\n</ul>\r\n<p>Размеры:</p>\r\n<ul>\r\n<li>В разложенном виде 82&times;44,5&times;98 см;</li>\r\n<li>В сложенном виде 99&times;45,5&times;20 см.</li>\r\n</ul>\r\n<p>Вес 6,5 кг.</p>\r\n<p><strong>Производитель: Graco, США</strong></p>','','N','N','','',1,0);
/*!40000 ALTER TABLE `bt_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_products_brands`
--

DROP TABLE IF EXISTS `bt_products_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_products_brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `nav` varchar(255) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `show` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nav` (`nav`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_products_brands`
--

LOCK TABLES `bt_products_brands` WRITE;
/*!40000 ALTER TABLE `bt_products_brands` DISABLE KEYS */;
INSERT INTO `bt_products_brands` VALUES (1,0,'HTC','htc','','Y','N','2011-02-03 20:32:52','0000-00-00 00:00:00'),(2,0,'Nokia','nokia','','Y','N','2011-02-04 09:39:31','0000-00-00 00:00:00'),(3,0,'Apple','apple','','Y','N','2011-02-04 09:41:14','0000-00-00 00:00:00'),(4,0,'Кама','kama','','Y','N','2011-02-04 10:07:02','0000-00-00 00:00:00'),(5,0,'Amtel','amtel','','Y','N','2011-02-04 10:09:01','0000-00-00 00:00:00'),(6,0,'GRACO','graco','','Y','N','2011-02-04 10:20:51','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `bt_products_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_products_topics`
--

DROP TABLE IF EXISTS `bt_products_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_products_topics` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `top` int(8) unsigned NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `nav` varchar(100) NOT NULL DEFAULT '',
  `show` enum('Y','N') NOT NULL DEFAULT 'Y',
  `deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `text` text NOT NULL,
  `types` longtext NOT NULL,
  `cases` text NOT NULL,
  `rate` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `top` (`top`),
  KEY `order` (`order`),
  KEY `deleted` (`deleted`),
  KEY `show` (`show`,`deleted`),
  KEY `show_2` (`show`),
  KEY `rate` (`rate`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_products_topics`
--

LOCK TABLES `bt_products_topics` WRITE;
/*!40000 ALTER TABLE `bt_products_topics` DISABLE KEYS */;
INSERT INTO `bt_products_topics` VALUES (1,0,0,'Телефоны','phones','Y','N','2011-02-03 20:28:45','0000-00-00 00:00:00','','','',0),(2,1,1,'Сотовые телефоны','cell-phones','Y','N','2011-02-03 20:29:09','0000-00-00 00:00:00','','','',5),(3,1,2,'Стилусы','styluses','Y','N','2011-02-04 09:55:47','0000-00-00 00:00:00','','','',1),(4,0,2,'Шины и диски','tires-and-wheels','Y','N','2011-02-04 10:04:46','0000-00-00 00:00:00','','','',0),(8,0,3,'Детские товары','children-s-products','Y','N','2011-02-04 10:16:12','0000-00-00 00:00:00','','','',0),(5,4,0,'Легковые шины','car-tires','Y','N','2011-02-04 10:04:59','0000-00-00 00:00:00','','','',2),(6,4,2,'Литые диски','alloy-wheels','Y','N','2011-02-04 10:05:09','0000-00-00 00:00:00','','','',0),(7,4,3,'Грузовые шины','truck-tires','Y','N','2011-02-04 10:05:20','0000-00-00 00:00:00','','','',0),(9,8,1,'Коляски','strollers','Y','N','2011-02-04 10:16:23','2011-02-04 10:16:49','','','',1),(10,8,2,'Автокресла','car-seats','Y','N','2011-02-04 10:17:49','0000-00-00 00:00:00','','','',0);
/*!40000 ALTER TABLE `bt_products_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_settings`
--

DROP TABLE IF EXISTS `bt_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(32) NOT NULL,
  `name` varchar(255) NOT NULL,
  `callname` varchar(128) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_settings`
--

LOCK TABLES `bt_settings` WRITE;
/*!40000 ALTER TABLE `bt_settings` DISABLE KEYS */;
INSERT INTO `bt_settings` VALUES (2,'CatalogNano','Товаров на страницу','onpage','8'),(3,'CatalogNano','Внутренняя валюта каталога','inner_currency','RUR'),(5,'CatalogNano','Наценка на конвертацию валюты, %','currency_margin','0'),(6,'CatalogNano','Округление цен','price_round','-1'),(7,'Shop','Почта для уведомления о заказе','notify_mail','andreydust@gmail.com'),(8,'Blocks','Название сайта','site_title','Booot'),(9,'Blocks','Почта администратора','admin_mail','andreydust@gmail.com'),(10,'Blocks','Тема оформления','site_theme','boilers');
/*!40000 ALTER TABLE `bt_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_shop_orders`
--

DROP TABLE IF EXISTS `bt_shop_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_shop_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `install` enum('Y','N') NOT NULL DEFAULT 'N',
  `comment` text NOT NULL,
  `paymethod` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_shop_orders`
--

LOCK TABLES `bt_shop_orders` WRITE;
/*!40000 ALTER TABLE `bt_shop_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `bt_shop_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_shop_orders_items`
--

DROP TABLE IF EXISTS `bt_shop_orders_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_shop_orders_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product` int(11) NOT NULL,
  `brand` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `top` int(11) NOT NULL,
  `price` float(11,2) NOT NULL,
  `count` int(11) NOT NULL,
  `total_fake` float(11,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_shop_orders_items`
--

LOCK TABLES `bt_shop_orders_items` WRITE;
/*!40000 ALTER TABLE `bt_shop_orders_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `bt_shop_orders_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_shop_paymethods`
--

DROP TABLE IF EXISTS `bt_shop_paymethods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_shop_paymethods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `name` varchar(128) NOT NULL,
  `show` enum('Y','N') NOT NULL DEFAULT 'Y',
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_shop_paymethods`
--

LOCK TABLES `bt_shop_paymethods` WRITE;
/*!40000 ALTER TABLE `bt_shop_paymethods` DISABLE KEYS */;
INSERT INTO `bt_shop_paymethods` VALUES (1,0,'Manual','Наличными','Y','<p>По Москве мы доставляем заказы собственной курьерской службой, поэтому возможна оплата при получении заказа. Оплата производится в рублях по курсу, указанному на сайте.</p>'),(2,1,'Manual','Пластиковой картой','Y',''),(3,2,'Manual','Безналичный расчет','Y',''),(4,3,'WM','WebMoney','Y','');
/*!40000 ALTER TABLE `bt_shop_paymethods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bt_shop_statuses`
--

DROP TABLE IF EXISTS `bt_shop_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bt_shop_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bt_shop_statuses`
--

LOCK TABLES `bt_shop_statuses` WRITE;
/*!40000 ALTER TABLE `bt_shop_statuses` DISABLE KEYS */;
INSERT INTO `bt_shop_statuses` VALUES (1,0,'New','Новый'),(2,0,'Profit','Доставлен'),(3,0,'Noprofit','Отказ');
/*!40000 ALTER TABLE `bt_shop_statuses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-02-04 12:32:47
