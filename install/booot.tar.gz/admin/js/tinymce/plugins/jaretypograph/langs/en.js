tinyMCE.addI18n('en.typograph',{
	desc : 'Typography'
});
