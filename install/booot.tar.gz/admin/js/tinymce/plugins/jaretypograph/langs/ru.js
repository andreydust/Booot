tinyMCE.addI18n('ru.typograph',{
	desc : 'Подтянуть типографику'
});
