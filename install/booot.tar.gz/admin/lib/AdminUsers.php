<?php
class AdminUsers {
	
	public $user;
	private $allAlowed = array('About');
	
	function __construct() {
		if(!isset($_SESSION)) {
			session_start();
		}
		
		$remote_user = '';
		if(!isset($_SERVER['PHP_AUTH_USER'])) {
			if(!isset($_SERVER['REDIRECT_REMOTE_USER'])) {
				if(!isset($_SERVER['REMOTE_USER'])) {
					
				} else $remote_user = $_SERVER['REMOTE_USER'];
			} else $remote_user = $_SERVER['REDIRECT_REMOTE_USER'];
		} else $remote_user = $_SERVER['PHP_AUTH_USER'];
		
		$user = db()->rows("SELECT * FROM `prefix_admin_users` WHERE `login` = '$remote_user'", MYSQL_ASSOC);
		$this->user = $user[0];
		
		if(isset($_GET['logout'])) $this->logout();
		if(empty($user)) $this->errorLogin();
		
		$this->login();
	}
	
	function isAllowed($module) {
		if($_SESSION['user']['type'] == 'a') return true;
		
		if(isset($_SESSION['user']['access'][$module]) || in_array($module, $this->allAlowed)) return true;
		else return false;
	}
	
	
	/**
	 * Выводит блок пользователя
	 */
	function userBar() {
		return tpl('widgets/userbar', array(
			'login'	=> $this->user['login'],
			'user'	=> $this->user
		));
	}
	
	/**
	 * Авторизация, сессия и т.д.
	 */
	function login() {
		//$_SERVER['PHP_AUTH_USER'];
		$_SESSION['user'] = $this->user;
		$_SESSION['user']['access'] = unserialize($this->user['access']);
		
		db()->query("UPDATE `prefix_admin_users` SET `lastenter` = NOW() WHERE `id` = {$this->user['id']}");
	}
	
	/**
	 * Указание браузеру авторизоваться по ложным данным
	 */
	function logout() {
		unset($_SESSION['user']);
		session_destroy();
		header("Location: http://douglas:42_will_do@".$_SERVER['SERVER_NAME']."/admin");
		exit();
	}
	
	/**
	 * Если пользователь авторизовался, но в базе такого нет
	 */
	function errorLogin() {
		echo
			'<h1>Ошибка авторизации</h1>
			<p>Пользователь не найден или сервер не поддерживает авторизацию</p>';
		exit();
	}
	
}