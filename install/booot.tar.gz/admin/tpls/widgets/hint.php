<div class="sideitem">
	<h2><?php echo $title?></h2>
	<p><?php echo $text?></p>
	<?php if(isset($link)) {?><a href="<?php echo $link?>">Раздел справки</a><?php }?>
</div>