<ul>

	<li><a href="?module=System&method=CheckFiles">Проверить состояние файлов</a></li>
	<!--<li><a href="?module=System&method=GenRobotsTxt">Создать robots.txt</a></li>-->
	<!--<li><a href="?module=System&method=GenSitemap">Сгенерировать карту сайта</a></li>-->
	<li><a href="?module=System&method=CodeEditor">Редактировать шаблоны, css, js</a></li>
	<li><a href="?module=System&method=HtPasswd">Пользователи системы администрирования</a></li>
	<li><a href="?module=System&method=Settings">Настройки модулей</a></li>

</ul>