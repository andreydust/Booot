<p>
<!--<img src="/Images/Logo.gif" alt="<?php echo $GLOBALS['config']['site']['title']?>" />-->
</p>
<p>Система управления сайтом — <?php echo $GLOBALS['config']['site']['title']?></p>