<!-- NOT USED -->
<!--
<div class="sidebar">
	<ul class="catalog_menu tournaments">
	<?php foreach($menu as $year=>$months) {?>
	<li><?php echo $year?>
	<ul>
		<?php foreach($months as $month) { ?>
		<li class="<?php echo $month['active']?'active':''?>"><a href="<?php echo $month['link']?>"><?php echo $month['name']?></a></li>
		<?php } ?>
	</ul>
        <li>
	<?php }?>
        </ul>
</div>
-->