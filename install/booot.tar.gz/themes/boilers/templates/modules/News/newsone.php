<div class="NewsItem">
	<p class="date"><?php echo $date?></p>
	<?php echo $content?>
</div>