<h2>Спасибо за заказ!</h2>

<?php block('basket_thanks')?>