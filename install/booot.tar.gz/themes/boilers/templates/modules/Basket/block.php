<?php if($count==0) {?>
	<div id="Basket"><div class="basketIcon"></div><div class="basketTitle">Корзина пуста</div></div>
<?php } else {?>
	<div id="Basket"><div class="basketIcon"></div><div class="basketTitle"><a href="/basket">Корзина</a></div></div>
	<div id="inBasket"><?php echo $count?> <?php echo plural($count, 'товаров', 'товар', 'товара')?> на сумму <?php echo number_format($summ, 0, '', ' ')?> <?php echo plural($summ, 'рублей', 'рубль', 'рубля')?></div>
<?php }?>