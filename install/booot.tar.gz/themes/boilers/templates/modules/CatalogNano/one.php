<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
<head>
	<title><?php echo $head_title?> — <?php echo $GLOBALS['config']['site']['title']?></title>
	<?php echo tpl('parts/head')?>
</head>

<body>

	<?php echo tpl('parts/header')?>

	<div class="ContentArea">
		<div class="ContentAreaIn">
			<div class="Content">
				<h1><?php echo $title?></h1>
				
				<div class="Product">
					<div class="ProductImagesBlock">
					<?php $images = img()->GetImages('CatalogNano',$product['id'])?>
						<div class="ProductImage">
						<?php $image = img()->GetMainImage('CatalogNano',$product['id'])?>
							<a href="<?php echo $image['src']?>" id="MainProductImage" class="lightview" rel="productGallery"><img src="<?php echo image($image['src'], 160, 160)?>" alt="<?php echo $product['name']?>" /></a>
						</div>
						<?php if(is_array($images) && count($images) > 1) {?>
						<div class="ProductSmallImages">
							<?php foreach ($images as $img) {
								if($img['id'] == $image['id']) $imgAct = 'Active';
								else  $imgAct = '';
							?>
								<a href="<?php echo $img['src']?>" class="lightview hiddenImages" id="hiddenImage<?php echo $img['id']?>" rel="productGallery<?php echo $imgAct?>"></a>
								<div class="lpImage <?php echo $imgAct?>">
									<a href="<?php echo $img['src']?>" id="visibleImage<?php echo $img['id']?>" rel="<?php echo image($img['src'], 160, 160)?>" class="SmallProductImage"><img src="<?php echo image($img['src'], 45, 45)?>" alt="<?php echo $product['name']?>" /></a>
								</div>
							<?php }?>
						</div>
						<?php }?>
					</div>
					<div class="ProductDescFull">
						<div class="ProductDescHint">В наличии</div>
						<div class="ProductDescPrice">
							<?php echo number_format($product['price'], 0, '', ' ')?> Р.
							
							<?php if($product['price'] < $product['priceOld']) {?>
							<div class="ProductPriceOld">
								<?php echo number_format($product['priceOld'], 0, '', ' ')?> Р.
							</div>
							<?php }?>
						</div>
						<noscript>
							<style type="text/css">
								.ProductDescOrder { display: none; }
								.noscriptDescOrder { display: block !important; }
							</style>
						</noscript>
						<!-- Без JS -->
						<div class="noscriptDescOrder">
							<form method="post" action="<?php echo linkByModule('Basket')?>/add/<?php echo $product['id']?>">
								<button style="<?php echo $product['inbasket']?'display:none':''?>">В корзину</button>
								<span style="<?php echo $product['inbasket']?'display:block':'display:none'?>">
									<button >Еще</button>
									<span class="RemoveBasket"><a class="ajaxLink" href="<?php echo linkByModule('Basket')?>/del/<?php echo $product['id']?>">Убрать из корзины</a></span>
								</span>
							</form>
						</div>
						<!-- С JS -->
						<div class="ProductDescOrder" id="productOneId<?php echo $product['id']?>">
							<button id="AddBasket" style="<?php echo $product['inbasket']?'display:none':''?>">В корзину</button>
							<span id="MoreBlock" style="<?php echo $product['inbasket']?'display:block':''?>">
								<button id="AddOneMore">Еще</button>
								<span class="RemoveBasket"><a class="ajaxLink" href="<?php echo linkByModule('Basket')?>/del/<?php echo $product['id']?>">Убрать из корзины</a></span>
							</span>
						</div>
						<div style="<?php echo $product['inbasket']?'display:block':''?>" id="InBasketHint">
							<?php echo $product['inbaskethint']?>
						</div>
					</div>
					
					<?php if(!empty($product['text']) || !empty($types) || !empty($files)) {?>
					<hr class="w98" />
					
					<div class="ProductDetails">
						<noscript>
							<style type="text/css">
							/*.ProductDetailsMenu { display:none; }*/
							#Description,#Types,#Docs { display:block; margin-bottom: 2em; }
							.noscriptTitle { display: block; }
							</style>
						</noscript>
						<div class="ProductDetailsMenu">
							<?php $activeTab = 'Active'; $showTab = 'display:block;'; ?>
							<?php if(!empty($product['text'])) {?><div class="<?php echo $activeTab; $activeTab = '';?>"><a href="#Description" class="ajaxLink">Описание</a></div><?php }?>
							<?php if(!empty($types)) {?><div class="<?php echo $activeTab; $activeTab = '';?>"><a href="#Types" class="ajaxLink">Характеристики</a></div><?php }?>
							<?php if(!empty($files)) {?><div class="<?php echo $activeTab; $activeTab = '';?>"><a href="#Docs" class="ajaxLink">Документы</a></div><?php }?>
						</div>
						<div class="ProductDetailsContainer">
							
							<?php if(!empty($product['text'])) {?>
							<div id="Description" style="<?php echo $showTab; $showTab = ''; ?>">
								<div class="noscriptTitle">Описание <?php echo mb_strtolower($title)?></div>
								<?php echo $product['text']?>
							</div>
							<?php }?>
							
							<?php if(!empty($types)) {?>
							<div id="Types" style="<?php echo $showTab; $showTab = ''; ?>">
								<div class="noscriptTitle">Характеристики <?php echo mb_strtolower($title)?></div>
								<table>
									<tr>
										<td class="w50 colSmaller colLeft">
										<?php foreach ($types['left'] as $typeGroup) {?>
											<table class="TypesGroup">
												<thead><tr><th colspan="2"><?php echo $typeGroup['name']?></th></tr></thead>
												<tbody>
												<?php foreach ($typeGroup['types'] as $type) {?>
													<tr>
														<td><?php echo $type['name']?> <?php if(!empty($type['desc'])) {?><span><span class="WhatIsThat7"></span></span><?php }?></td>
														<td><div class="rel"><?php echo $type['val']?>
														<?php if(!empty($type['desc'])) {?>
															<div class="TypeHint TypeHintInList">
																<div class="TypeHintCorner"></div>
																<div class="TypeHintName"><?php echo $type['name']?></div>
																<div class="TypeHintText"><?php echo $type['desc']?></div>
																<div class="TypeHintClose"><span class="ajaxLink">Закрыть</span></div>
															</div>
														<?php }?>
														</div></td>
													</tr>
												<?php }?>
												</tbody>
											</table>
										<?php }?>
										</td>
										<td class="w50 colSmaller colRight">
										<?php foreach ($types['right'] as $typeGroup) {?>
											<table class="TypesGroup">
												<thead><tr><th colspan="2"><?php echo $typeGroup['name']?></th></tr></thead>
												<tbody>
												<?php foreach ($typeGroup['types'] as $type) {?>
													<tr>
														<td><?php echo $type['name']?> <?php if(!empty($type['desc'])) {?><span><span class="WhatIsThat7"></span></span><?php }?></td>
														<td><div class="rel"><?php echo $type['val']?>
														<?php if(!empty($type['desc'])) {?>
															<div class="TypeHint TypeHintInList">
																<div class="TypeHintCorner"></div>
																<div class="TypeHintName"><?php echo $type['name']?></div>
																<div class="TypeHintText"><?php echo $type['desc']?></div>
																<div class="TypeHintClose"><span class="ajaxLink">Закрыть</span></div>
															</div>
														<?php }?>
														</div></td>
													</tr>
												<?php }?>
												</tbody>
											</table>
										<?php }?>
										</td>
									</tr>
								</table>
							</div>
							<?php }?>
							
							<?php if(!empty($files)) {?>
							<div id="Docs" style="<?php echo $showTab; $showTab = ''; ?>">
								<div class="noscriptTitle">Файлы и документация <?php echo mb_strtolower($title)?></div>
								<div id="DocsWrap">
									
								<?php foreach ($files as $file) {?>
									<div class="Doc">
										<div class="DocIcon"><a href="<?php echo $file['src']?>"><img src="<?php echo $file['icon']?>" width="48" height="48" alt="<?php echo strtoupper($file['filetype'])?>" /></a></div>
										<div class="DocDetails">
											<div class="DocName"><a href="<?php echo $file['src']?>"><?php echo $file['name']?></a></div>
											<div class="DocType"><?php echo strtoupper($file['filetype'])?> <?php echo bytes_to_str($file['fileinfo']['size'])?></div>
										</div>
									</div>
								<?php }?>
								
								</div>
							</div>
							<?php }?>
							
						</div>
					</div>
					<?php }?>
				</div>
			</div>
			
			<div class="SideBar">
				<?php echo giveObject('CatalogNano')->AlsoBoughtBlock()?>
				
				<?php echo giveObject('CatalogNano')->SeenBlock(3)?>
				
				<?php echo giveObject('Content')->SubMenu(21)?>
			</div>
			
			<div class="clear"></div>
		</div>
	</div>

	<?php echo tpl('parts/footer')?>

</body>
</html>