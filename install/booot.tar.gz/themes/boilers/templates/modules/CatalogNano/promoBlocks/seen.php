<?php if($count>$limit) {?>
<h2 class="rightHeader"><a href="<?php echo linkByModule('CatalogNano')?>/seen">Вы смотрели</a> (<?php echo $count?>)</h2>
<?php } else {?>
<h2 class="rightHeader">Вы смотрели</h2>
<?php }?>

<?php echo $littleProductsList?>

<hr class="rightHR" />