<h2 class="rightHeader">С этим товаром также покупают</h2>

<?php echo $littleProductsList?>

<hr class="rightHR" />