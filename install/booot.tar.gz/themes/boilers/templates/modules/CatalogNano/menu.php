<?php if(!empty($topics)) {?>
	<div id="catalogMenu">
		<ul>
		<?php foreach ($topics[0] as $root) {?>
			<li class="catalogTopLevel <?php echo $root['active']?'Active':''?>"><a href="<?php echo $root['link']?>" class="ctLink <?php echo $root['active']?'Active':''?>"><?php echo $root['name']?></a>
			<?php if(isset($topics[$root['id']]) && !empty($topics[$root['id']])) {?>
				<div class="ActiveOverflower"><div></div></div>
				<ul>
				<?php foreach ($topics[$root['id']] as $sub) {
					if($sub['active']) {?>
						<li class="ActiveSub"><a href="<?php echo $sub['link']?>" class="ActiveSubA"><?php echo $sub['name']?></a> (<?php echo $sub['count']?>)</li>
					<?php } else {?>
						<li><a href="<?php echo $sub['link']?>"><?php echo $sub['name']?></a> (<?php echo $sub['count']?>)</li>
					<?php }?>
				<?php }?>
				</ul>
			<?php }?>
			</li>
		<?php }?>
		</ul>
	</div>
<?php }?>