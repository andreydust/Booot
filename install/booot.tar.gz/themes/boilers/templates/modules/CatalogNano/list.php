<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
<head>
	<title><?php echo $head_title?> — <?php echo $GLOBALS['config']['site']['title']?></title>
	<?php echo tpl('parts/head')?>
</head>

<body>

	<?php echo tpl('parts/header')?>


	<div class="ContentArea">
		<div class="ContentAreaIn">

			<div class="Content">
				
				<h1><?php echo $title?></h1>
				
				<div id="selectBrandsPrice">
				<?php
				$selectShow = false;
				if((!empty($brands) && count($brands) > 1) || $slider_vals['min']+200 < $slider_vals['max']) { $selectShow = true;?>
					<form action="" method="get">
						<input type="hidden" name="addGet" value="<?php echo $brand_price_link?>" />
					<?php if(!empty($brands) && count($brands) > 1) {?>
						<?php foreach ($brands as $brand) {?>
						<span><input type="checkbox" name="brands[]" value="<?php echo $brand['nav']?>" id="brand<?php echo $brand['id']?>" class="selectBrand" <?php echo $brand['checked']?'checked="checked"':''?> /><label for="brand<?php echo $brand['id']?>"><a href="<?php echo $brand['link']?>"><?php echo $brand['name']?></a></label></span>
						<?php }?>
						<span class="selectBrandsAll ajaxLink" id="allBrands">Все бренды</span>
					<?php }?>
					
						<div id="selectPrice">
						<?php if($slider_vals['min']+200 < $slider_vals['max']) {?>
							<div id="selectPriceLabel">
								Цена:
								<input type="hidden" id="stepValue" value="<?php echo $slider_vals['step']?>" />
								<input type="hidden" id="minValue" value="<?php echo $slider_vals['min']?>" />
								<input type="hidden" id="maxValue" value="<?php echo $slider_vals['max']?>" />
								<input type="hidden" id="fromValue" name="PriceFromValue" value="<?php echo $slider_vals['from']?>" />
								<input type="hidden" id="toValue" name="PriceToValue" value="<?php echo $slider_vals['to']?>" />
							</div>
							<div id="selectPriceRange"></div>
						<?php }?>
							<div id="selectPriceGo"><button>Показать</button></div>
						</div>
					
					</form>
				<?php }?>
				</div>
				
				<?php if($selectShow) {?>
				<hr class="w98" />
				<?php }?>
				
				<div class="ProductsList">
				<?php if(count($products) == 0) {?>
				<p>Товары не найдены или отсутствуют</p>
				<?php }?>
				<?php foreach ($products as $product) {?>
					<?php $img = img()->GetMainImage('CatalogNano', $product['id']);?>
					<div class="Product">
						<div class="ProductImage">
							<a href="<?php echo $product['link']?>"><img src="<?php echo image($img['src'], 85, 120)?>" alt="<?php echo $product['brand_name']?> <?php echo $product['name']?>" /></a>
						</div>
						<div class="ProductDesc">
							<div class="ProductTitle"><a href="<?php echo $product['link']?>"><?php echo $product['brand_name']?> <?php echo $product['name']?></a></div>
							<div class="ProductText"><?php echo $product['snippet']?></div>
							<div class="ProductPriceNCompare">
								<div class="ProductPrice">
									<?php echo number_format($product['price'], 0, '', ' ')?> Р.
									<?php if($product['price'] < $product['priceOld']) {?>
									<div class="ProductPriceOld">
										<?php echo number_format($product['priceOld'], 0, '', ' ')?> Р.
									</div>
									<?php }?>
								</div>
							</div>
						</div>
					</div>
				<?php }?>
				</div>
				
				<?php echo $paging?>
				
			</div>
			
			<div class="SideBar">
				
				<?php echo giveObject('CatalogNano')->SeenBlock(3)?>
				
				<?php echo giveObject('Content')->SubMenu(21)?>
			</div>

			<div class="clear"></div>
			
		</div>
	</div>
	
	<?php echo tpl('parts/footer')?>


</body>
</html>