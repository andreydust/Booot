<?php if(count($products) > 0) {?>
	<div class="ProductsList">
	<?php foreach ($products as $product) {?>
		<?php $img = img()->GetMainImage('CatalogNano', $product['id']);?>
		<div class="Product">
			<div class="ProductImage">
				<a href="<?php echo $product['link']?>"><img src="<?php echo image($img['src'], 85, 120)?>" alt="<?php echo $product['brand']?$product['brand']['name'].' ':''?><?php echo $product['name']?>" /></a>
			</div>
			<div class="ProductDesc">
				<div class="ProductTopic"><a href="<?php echo $product['topic']['link']?>"><?php echo $product['topic']['name']?></a></div>
				<div class="ProductTitle"><a href="<?php echo $product['link']?>"><?php echo $product['brand']?$product['brand']['name'].' ':''?><?php echo $product['name']?></a></div>
				<div class="ProductText"><?php echo $product['snippet']?></div>
				<div class="ProductPrice">
					<?php echo number_format($product['price'], 0, '', ' ')?> Р.
					<?php if($product['price'] < $product['priceOld']) {?>
					<div class="ProductPriceOld">
						<?php echo number_format($product['priceOld'], 0, '', ' ')?> Р.
					</div>
					<?php }?>
				</div>
			</div>
		</div>
	<?php }?>
	</div>
<?php }?>