<div class="Paging">
	Страницы:
	<?php for ($i=1; $i<=$pages_count; $i++) {?>
		<a <?php echo ($page_current==$i?'class="Active"':'')?> href="<?php echo getget(array('page'=>$i))?>"><?php echo $i?></a>
	<?php }?>
</div>