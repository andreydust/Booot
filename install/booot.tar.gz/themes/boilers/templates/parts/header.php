	<div id="header">
		<div id="headerIn">
			<div id="logo"><a href="/" title="На главную">Booot <span class="black">ru</span></a></div>
			<div id="subLogo"><?php block('sub_logo')?></div>
			<div id="mainMenu">
				<ul>
					<?php echo giveObject('Content')->MainMenu()?>
				</ul>
			</div>
			<div id="topPhone"><?php block('phone')?></div>
			<div id="callMe"><span class="ajaxLink">Позвоните мне</span>
				<div id="callMeWindow">
					<div id="callMeWindowName">Позвоните мне</div>
					<div id="callMeWindowClose"></div>
					<div id="callMeWindowForm">
						<label for="callMeWindowFormName">Ваше имя</label>
						<input type="text" name="CallMeName" id="callMeWindowFormName" />
						<label for="callMeWindowFormPhone">Номер телефона</label>
						<input type="text" name="CallMePhone" id="callMeWindowFormPhone" />
						<button id="callMeWindowSend">Отправить</button>
					</div>
				</div>
			</div>
			<div id="icqBlock"><div class="icqIcon"></div><div class="icqNumber"><?php block('icq')?></div></div>
			<div id="skypeBlock"><div class="skypeIcon"></div><div class="skypeName"><?php block('skype')?></div></div>

			<div id="BasketBlockWrap"><?php echo giveObject('Basket')->Block()?></div>
		</div>
	</div>

	<div id="menu">
		<div id="menuIn">
			<?php echo giveObject('CatalogNano')->Menu();?>
			<?php $openMenu = giveObject('CatalogNano')->menuOpened?>
			<div id="searchExpand" style="<?php echo $openMenu?'':'display:none;'?>"><span class="ajaxLink">Поиск</span></div>
			<div id="searchBar" style="<?php echo $openMenu?'display:none;':''?>">
				<form action="/catalog/search" method="get"><div>
					<input type="text" name="string" class="search" id="SearchString" value="<?php echo isset($_GET['string'])?htmlspecialchars($_GET['string']):''?>" />
					<input type="submit" value="Найти" class="submit" />
				</div></form>
				<div class="example">Например: <a href="" class="ajaxLink"><?php echo giveObject('CatalogNano')->SearchForExample()?></a></div>
			</div>
			<div id="breadCrumbs" style="<?php echo $openMenu?'':'display:none;'?>">
				<?php echo giveObject('Content')->breadCrumbs()?>
			</div>
		</div>
	</div>