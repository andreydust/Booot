	<div id="footer">
		<div id="footerIn">
			<div id="footerLogo">Booot <span class="black">ru</span></div>
			<div id="footerAddress"><address><?php block('address')?></address></div>
			<div id="footerPhone"><?php block('phone')?></div>
			<div id="footerWriteMe"><a href="/feedback">Напишите нам</a></div>
			<div id="footerMenu">
				<ul>
					<?php echo giveObject('Content')->MainMenu()?>
				</ul>
			</div>
			<div id="footerShopDesc"><?php block('about_footer')?></div>
			<div id="footerCopyRights"><?php block('details_footer')?></div>
			<div id="DevelopersDevelopersDevelopers">
				<div id="weboutsource"><a href="http://weboutsource.ru/create-and-sell-ishop" title="Продажа интернет-магазинов"><img src="<?php echo $sdir?>/images/weboutsource.png" width="87" height="45" alt="Web Outsource" /></a></div>
			</div>
		</div>
	</div>