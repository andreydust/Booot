	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="shortcut icon" href="<?php echo $sdir?>/images/favicon.ico" />
	<!--[if lte IE 7]>
	<script type="text/javascript" src="http://dustweb.ru/ieSunset/ieSunset.js"></script>
	<![endif]-->
	
	<!-- CSS -->
	<!-- Markup -->
	<link href="<?php echo $sdir?>/css/layout.css" rel="stylesheet" type="text/css" media="screen" />
	<!-- Fonts and controls -->
	<link href="<?php echo $sdir?>/css/typo.css" rel="stylesheet" type="text/css" media="screen" />
	<!-- Auto Forms -->
	<link href="/css/autoforms.css" rel="stylesheet" type="text/css" media="screen" />
	<!-- Comments CSS -->
	<link href="/css/comments.css" rel="stylesheet" type="text/css" media="screen" />
	<!-- Fancy Box -->
	<link href="/js/fancybox/jquery.fancybox-1.3.4.css" rel="stylesheet" type="text/css" media="screen" />
	
	
	<!-- JS -->
	<!-- jQuery -->
	<script type="text/javascript" src="/js/jquery-1.4.4.min.js"></script>
	<!-- jQuery UI -->
	<script type="text/javascript" src="/js/jquery-ui-1.8.6.custom.min.js"></script>
	<!-- Fancy Box -->
	<script type="text/javascript" src="/js/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
	<script type="text/javascript" src="/js/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
	<!-- Site Interface -->
	<script type="text/javascript" src="<?php echo $sdir?>/js/interface.js"></script>
	
	<?php echo $GLOBALS['head_add']?>