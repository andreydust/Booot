<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
<head>
	<title><?php echo $GLOBALS['config']['site']['title']?></title>
	<?php echo tpl('parts/head')?>
</head>

<body>

	<?php echo tpl('parts/header')?>


	<div class="ContentArea">
		<div class="ContentAreaIn">
			<div class="Content">
				<h1>Рекомендуем</h1>
				<?php echo giveObject('CatalogNano')->FeaturedList(4)?>
			</div>
			
			<div class="SideBar">
				<?php echo giveObject('Content')->SubMenu(16)?>
			</div>
			
			<hr />
		</div>

		<div class="ContentAreaIn">
			<div class="Content">
				<p class="Bigger"><?php block('main_text')?></p>
			</div>
			
			<div class="SideBar">
				<?php echo giveObject('News')->LastNewsBlock()?>
			</div>

			<div class="clear"></div>
		</div>
	</div>
	
	<?php echo tpl('parts/footer')?>


</body>
</html>