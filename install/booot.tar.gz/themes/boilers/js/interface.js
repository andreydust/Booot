
$(function(){
 
	//Окно перезвона
	$('#callMe span.ajaxLink').click(function(){
		$('#callMeWindow').fadeIn('fast','easeOutCubic');
		$('#callMeWindowFormName').focus();
	});
	$('#callMeWindowClose').click(function(){
		$('#callMeWindow').fadeOut('fast','easeOutCubic');
		$('#callMeWindowFormName').val('');
		$('#callMeWindowFormPhone').val('');
	});
	$('#callMeWindowSend').click(function(){
		$.ajax({
			type: 'post',
			url: '/Content/CallMe',
			data: {
				'name': $('#callMeWindowFormName').val(),
				'phone': $('#callMeWindowFormPhone').val()
			},
			success: function(reply){
				if(reply == 'fields_error') {
					alert('Вы не заполнили все поля!');
					return false;
				} else
				if(reply == 'error') {
					alert('Проблемы при отправке :(');
					return false;
				} else {
					$('#callMeWindowClose').trigger('click');
					$('#callMe span.ajaxLink').removeClass('ajaxLink').unbind().html('Спасибо, мы перезвони́м!');
				}
			}
		});
		return false;
	});

	//Поиск
	$('#searchBar div.example .ajaxLink').click(function(){
		$('#SearchString').val($(this).text()).focus();
		return false;
	});
	
	//Поиск, когда мы в каталоге
	$('#searchExpand .ajaxLink').click(function(){
		$('#catalogMenu .Active').removeClass('Active');
		$('#breadCrumbs').hide();
		$('#searchBar').fadeIn('fast','easeInCubic');
		$('#SearchString').focus();
		$(this).parent().hide();
	});
	
	//Меню каталога
	$('#catalogMenu .catalogTopLevel .ctLink').click(function(){
		if($(this).parent().hasClass('Active')) return false;
		$(this).parent().parent().find('.Active').removeClass('Active');
		$(this).parent().addClass('Active');
		$(this).addClass('Active');

		if($('#searchExpand').css('display') == 'none') {
			$('#breadCrumbs').show();
			$('#searchBar').hide();
			$('#searchExpand').show();
		}

		return false;
	});

	//Характеристика в подборе
	var hint = false;
	$('.WhatIsThat7').click(function(){
		preHint = hint;
		hint = $(this).parent().parent().parent().find('.TypeHint');
		if(hint.css('display') == 'block') {
			hint.find('.TypeHintClose .ajaxLink').trigger('click');
			return true;
		}
		if(preHint) preHint.find('.TypeHintClose .ajaxLink').trigger('click');
		hint.fadeIn('fast','easeInCubic');
	});
	$('.TypeHintClose .ajaxLink').click(function(){
		$(this).parent().parent().fadeOut('fast','easeOutCubic');
	});

	//Слайдер
	var fromValue = $('#fromValue');
	var toValue = $('#toValue');
	var minValue = parseInt($('#minValue').val());
	var maxValue = parseInt($('#maxValue').val());
	var stepValue = parseInt($('#stepValue').val());
	$('#selectPriceRange').slider({
		range: true,
		min: minValue,
		max: maxValue,
		step: stepValue,
		values: [ fromValue.val(), toValue.val() ],
		slide: function( event, ui ) {
			//$( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
			//console.log(ui.values);
			fromValue.val(ui.values[0]);
			toValue.val(ui.values[1]);
			fromWidget.text(ui.values[0]);
			toWidget.text(ui.values[1]);
		}

	})
		.find('a:last')
			.html('<span id="rightSliderValue">'+toValue.val()+'</span>')
			.addClass('rightSlider')
		.parent()
		.find('a:first')
			.html('<span id="leftSliderValue">'+fromValue.val()+'</span>')
			.addClass('leftSlider');
	var fromWidget = $('#leftSliderValue');
	var toWidget = $('#rightSliderValue');
	
	//Сравнить
	$(".ajaxCompare").click(function(){
		$(this).effect('transfer', { to: "#CompareBlock", className: "ajaxCompareTransfer" }, 500, function(){
			$.ajax({
				type: 'post',
				url: '/Catalog/Compare',
				dataType: 'json',
				data: {
					'add': $(this).attr('id').substr(7)
				},
				success: function(reply){
					$('#CompareBlock').html(reply.block);
				}
			});
		});
		$(this).fadeOut(400);
		
		return false;
	});
	//Убрать из сравнения
	$('.ajaxCompareRemove').live('click', function(){
		$.ajax({
			type: 'post',
			url: '/Catalog/Compare',
			dataType: 'json',
			data: {
				'del': $(this).attr('id').substr(13)
			},
			success: function(reply){
				$('#CompareBlock').html(reply.block);
			}
		});
		$('#compare'+$(this).attr('id').substr(13)).fadeIn(400);
		
		return false;
	});
	
	//Изображения везде
	$(".lightview").fancybox({
		'transitionIn'	: 'elastic'
	});
	
	//Изображения в товаре
	$('.SmallProductImage').click(function(){
		var parent = $(this).parent();
		if(parent.hasClass('Active')) return false;
		
		var id = $(this).attr('id').substr(12);

		$('.hiddenImages').attr('rel', 'productGallery');
		$('#hiddenImage' + id).attr('rel', 'productGalleryActive');
		
		$('#MainProductImage').attr('href', $(this).attr('href'));
		$('#MainProductImage img').attr('src', $(this).attr('rel'));
		parent.parent().find('.Active').removeClass('Active');
		parent.addClass('Active');
		
		$("#MainProductImage").fancybox({
			'transitionIn'	: 'elastic',
			'transitionOut'	: 'elastic'
		});
		
		return false;
	});
	
	//Изображения в товаре
	$("#MainProductImage").fancybox({
		'transitionIn'	: 'elastic',
		'transitionOut'	: 'elastic'
	});

	
	//Табы в товаре
	$('.ProductDetailsMenu div').click(function(){
		if($(this).hasClass('Active')) return false;
		
		var currentTab = $(this).parent().find('.Active');
		currentTab.removeClass('Active');
		$(currentTab.find('a').attr('href')).hide();
		$(this).addClass('Active');
		$($(this).find('a').attr('href')).show();
		return false;
	});

	
	//Заказ в товаре
	//В корзину
	$('#AddBasket').click(function(){
		var obj = $(this);
		$.ajax({
			type: 'post',
			url: '/Basket/Add',
			data: {
				'id': $('.ProductDescOrder').attr('id').substr(12)
			},
			success: function(reply){
				if(!reply.result) {
					//alert("Извитите, что-то пошло не так :(");
				} else {
					$('#BasketBlockWrap').html(reply.block);
					obj.hide();
					$('#MoreBlock').fadeIn('fast','easeInCubic');
					$('#InBasketHint').html(reply.hint).slideDown('fast','easeInCubic');
				}
			}
		});
	});
	//Убрать из корзины
	$('#MoreBlock .RemoveBasket .ajaxLink').click(function(){
		$.ajax({
			type: 'post',
			url: '/Basket/Del',
			data: {
				'id': $('.ProductDescOrder').attr('id').substr(12)
			},
			success: function(reply){
				if(!reply.result) {
					//alert("Извитите, что-то пошло не так :(");
				} else {
					$('#BasketBlockWrap').html(reply.block);
					$('#AddBasket').fadeIn('fast','easeInCubic');
					$('#MoreBlock').hide();
					$('#InBasketHint').slideUp('fast','easeOutCubic');
				}
			}
		});
		moreClickCount = 0;
		return false;
	});
	//Еще в корзину
	var moreClickCount = 0;
	$('#AddOneMore').click(function(){
		$.ajax({
			type: 'post',
			url: '/Basket/Add',
			data: {
				'id': $('.ProductDescOrder').attr('id').substr(12)
			},
			success: function(reply){
				if(!reply.result) {
					//alert("Извитите, что-то пошло не так :(");
				} else {
					$('#BasketBlockWrap').html(reply.block);
					$('#InBasketHint').html(reply.hint);
				}
			}
		});
		moreClickCount++;
		if(moreClickCount == 3) $(this).text('Себе :)');
		else $(this).text('Еще');
	});
	
	
	//Заглушка на сабмит формы
	$('#basketListForm').submit(function(){return false;});
	
	//Редактирование количества в корзине
	$('.editCount').keyup(function(){
		var id = $(this).attr('id').substr(5);
		var val = parseInt($(this).val());
		var parentObj = $(this).parent().parent();
		$.ajax({
			type: 'post',
			url: '/Basket/Edit',
			data: {
				'id':		id,
				'count':	val
			},
			success: function(reply){
				if(!reply.result) {
					//alert("Извитите, что-то пошло не так :(");
				} else {
					$('#BasketBlockWrap').html(reply.block);
					parentObj.find('.dPrice').html(reply.price);
					parentObj.find('.dTPrice').html(reply.tprice);
					$('#dSTCount').html(reply.totals.count);
					$('#dSTPrice').html(reply.totals.summ);
				}
			}
		});
	});
	
	//Убрать из корзины
	$('.blDel .ajaxLink').click(function(){
		var obj = $(this);
		$.ajax({
			type: 'post',
			url: '/Basket/Del',
			data: {
				'id': $(this).attr('id').substr(3)
			},
			success: function(reply){
				if(!reply.result) {
					alert("Извитите, что-то пошло не так :(");
				} else {
					if(reply.empty) {
						document.location = '';
						return false;
					}
					$('#BasketBlockWrap').html(reply.block);
					obj.parent().parent().remove();
					$('#dSTCount').html(reply.totals.count);
					$('#dSTPrice').html(reply.totals.summ);
				}
			}
		});
		
		return false;
	});
	
	//Варианты оплаты
	$('#PayMethodSelectVariants .ajaxLink').click(function(){
		var radio = $('#' + $(this).parent().attr('for'));
		$('#PayMethodSelectText div').hide();
		$(this).parent().parent().parent().find('.Active').removeClass('Active');
		$(this).parent().parent().addClass('Active');
		$($(this).attr('href')).show();
		radio.attr('checked', true);
		return false;
	});
	
	
	//Все бренды
	$('#allBrands').click(function(){
		$(this).parent().find('.selectBrand').attr('checked', true);
	});

});
