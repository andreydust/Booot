<?php

class MainPage {
	
	function __construct() {
		
	}
	
	public function Output() {
		return tpl('mainpage', array(
			
		));
	}
	
}
