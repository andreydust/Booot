<?php

class CatalogNano {
	
	private $data, $holder;
	public $path, $topic, $product, $menuOpened;
	
	private $localCacheLink, $productsFilter, $currentTopicTypes;
	
	private $alter_pages = array(
		'seen'		=> array('method'=>'Seen', 'name'=>'Вы смотрели'),
		'search'	=> array('method'=>'Search', 'name'=>'Поиск по каталогу')
	);
	
	/**
	 * Конструктор модуля
	 */
	function __construct() {
		if(!session_id()) session_start();
		$this->data = $GLOBALS['data'];
	}
	
	/**
	 * Метод вызываемый для работы модуля
	 */
	function Output() {
		$this->buildModulePath();
		return $this->startController();
	}
	
	/**
	 * Создает и проверяет путь модуля на валидность
	 * заполняет необходимые для работы модуля переменные
	 * $this->holder, $this->path, $this->topic, $this->product
	 *
	 * При случае неверной адресации отдает 404
	 *
	 * Валидный адрес:
	 * [группа](/.../[группа](/[товар]))
	 *
	 */
	private function buildModulePath() {
		$this->holder = end($GLOBALS['path']);
		
		$request =
			strpos($_SERVER['REQUEST_URI'], '?')!==false
			?
				substr($_SERVER['REQUEST_URI'], 0, strpos($_SERVER['REQUEST_URI'], '?'))
			:
				$_SERVER['REQUEST_URI'];
		
		$mlink = trim(str_replace(linkById($this->holder['id']), '', $request));
		$mpath = array_filter(explode('/', $mlink));
		
		//Альтернативные страницы
		$check_alter = current($mpath);
		if(isset($this->alter_pages[$check_alter])) {
			if(!method_exists($this, $this->alter_pages[$check_alter]['method'])) page404();
			
			$params_path = array();
			$params_path[] = array(
				'type'		=> 'alter_page',
				'method'	=> $this->alter_pages[$check_alter]['method'],
				'data'		=> $check_alter
			);
			
			foreach ($mpath as $ppath) {
				if(!isset($skipFirst)) { $skipFirst=true; continue; }
				$params_path[] = array(
					'type'	=> 'param',
					'data'	=> $ppath
				);
			}
			$this->path = $params_path;
			return true;
		}
		
		$topics = $this->data->GetData('products_topics', "AND `show` = 'Y'");
		$topicsByTop = array();
		foreach ($topics as $topic) $topicsByTop[$topic['top']][] = $topic;
		
		$top = 0;
		$path = array();
		//По путю модуля
		foreach ($mpath as $k=>$chunk) {
			//По топикам
			if(isset($topicsByTop[$top]))
			foreach ($topicsByTop[$top] as $topic) {
				if($topic['nav'] == $chunk) {
					$path[$k]['type'] = 'topic';
					$path[$k]['data'] = $topic;
					$this->topic = $topic;
					$top = $topic['id'];
					unset($mpath[$k]);
					break;
				}
			}
		}
		
		//Если остался неизвестный трэшняк, то сори, 404
		if(count($mpath) > 1) page404();
		
		//А так это возможно товар
		if(count($mpath) == 1) {
			$product = current($mpath);
			$curTopic = end($path);
			$curTopic = $curTopic['data'];
			$curProduct = end($mpath);
			if(is_numeric($curProduct)) {
				$product_sql = "AND `id` = ".(int)$curProduct;
			} else {
				$product_sql = "AND `nav` = '".q($curProduct)."'";
			}
			$productData = db()->rows("SELECT * FROM `prefix_products` WHERE `deleted` = 'N' AND `show` = 'Y' AND `top` = ".(int)$curTopic['id']." $product_sql");
			$productCount = count($productData);
			if($productCount == 0) page404();
			elseif($productCount > 1) $productData = current($productData);
			else $productData = current($productData);
			
			$this->product = $productData;
			
			$path[] = array(
				'type'	=> 'product',
				'data'	=> $productData
			);
		}
		
		$this->path = $path;
		return true;
	}
	
	/**
	 * Запуск нужного метода модуля
	 */
	private function startController() {
		//Альтернативные страницы
		$check_alter = current($this->path);
		if($check_alter['type'] == 'alter_page') {
			//unset($this->path[0]);
			return $this->$check_alter['method']();
		}
		
		$last = end($this->path);
		
		//Главная каталога
		if(empty($this->path)) {
			//return $this->ProductsOnMain();
		}
		//Товар
		elseif($last['type'] == 'product') {
			return $this->Product();
		}
		//Группа (список товаров)
		else {
			return $this->ProductsList();
		}
	}
	
	
	/**
	 * Меню каталога
	 */
	function Menu() {
		$counts_ = db()->rows("SELECT `top` , COUNT(`id`) AS `count` FROM `prefix_products` WHERE `deleted`='N' AND `show`='Y' GROUP BY `top`");
		$counts = array();
		foreach ($counts_ as $count) {
			$counts[$count['top']] = $count['count'];
		}
		$active_ids = array();
		if(!empty($this->path)) {
			foreach ($this->path as $v) {
				if($v['type'] == 'topic') {
					$active_ids[] = $v['data']['id'];
				}
			}
		}
		$topics = $this->data->GetData('products_topics', "AND `show` = 'Y'");
		$topicsByTop = array();
		foreach ($topics as $v) {
			$v['link'] = $this->Link($v['id']);
			$v['count'] = isset($counts[$v['id']])?$counts[$v['id']]:0;
			
			//set active
			if(in_array($v['id'], $active_ids)) {
				$v['active'] = true;
				$this->menuOpened = true;
			} else {
				$v['active'] = false;
			}
			
			
			$topicsByTop[$v['top']][$v['id']] = $v;
		}
		unset($topics);
		
		return tpl('modules/'.__CLASS__.'/menu', array(
			'topics'	=> $topicsByTop
		));
	}
	
	
	/**
	 * Генерация ссылки
	 */
	function Link($topic_id=0, $product_id=0) {
		$topic_id=(int)$topic_id;
		
		if($topic_id != 0 || $product_id != 0) {
			$topics = $this->data->GetData('products_topics', "AND `show` = 'Y'");
			
			if($product_id !== 0) {
				if($topic_id == 0) {
					$product = $this->data->GetDataById('products', $product_id);
					$topic_id = $product['top'];
				}
				$product_link = '/'.$product_id;
			} else {
				$product_link = '';
			}
			
			foreach($topics as $i) $topicsByTop[$i['top']][$i['id']] = $i;
			$linkById = function($topic_id, $topicsByTop, $topics, $linkById) {
				if($topic_id==0) return;
				return $linkById($topics[$topic_id]['top'], $topicsByTop, $topics, $linkById).'/'.$topics[$topic_id]['nav'];
			};
			$topic_link = $linkById($topic_id, $topicsByTop, $topics, $linkById);
			
			$prepared_link = $topic_link.$product_link;
		}
		
		if(empty($this->localCacheLink)) $this->localCacheLink = linkByModule(__CLASS__);
		
		return $this->localCacheLink.$prepared_link;
	}
	
	
	/**
	 * Массив для хлебных крошек модуля
	 *
	 * array( array('name','link') )
	 */
	public function breadCrumbs() {
		if(!empty($this->path)) {
			$ret = array();
			foreach ($this->path as $i) {
				if($i['type'] == 'alter_page') {
					$ret[] = array(
						'name'	=> $this->alter_pages[$i['data']]['name'],
						'link'	=> linkByModule(__CLASS__).'/'.$i['data']
					);
					break;
				}
				$link = '';
				if($i['type'] == 'topic') $link = $this->Link($i['data']['id']);
				if($i['type'] == 'product') $link = $this->Link($i['data']['top'], $i['data']['id']);
				$ret[] = array('name'=>$i['data']['name'], 'link'=>$link);
			}
			return $ret;
		} else return array();
	}
	
	
	
	/**
	 * Листинг товаров
	 */
	function ProductsList() {
		
		$additional_brand_title = '';
		$product_ids = array();
		$addGet = array();
		$db = db();
		
		//Запрос
		if(isset($_GET['addGet'])) {
			parse_str($_GET['addGet'], $addGet);
			unset($_GET['addGet']);
			$_GET = array_merge($_GET, $addGet);
		}
		
		//Хар-ки топика
		if(empty($this->currentTopicTypes)) $this->currentTopicTypes = unserialize($this->topic['types']);
		
		//Товары
		$products = $db->rows("
			SELECT p.*, b.name AS `brand_name` FROM `prefix_products` AS p
			LEFT JOIN `prefix_products_brands` AS b ON b.id = p.brand
			WHERE
				p.`deleted` = 'N' AND
				p.`show` = 'Y' AND
				p.`top` = ".(int)$this->topic['id']."
			ORDER BY `rate` DESC
		", MYSQL_ASSOC);
		foreach ($products as $k=>$product) {
			//Цена
			$products[$k]['priceOld'] = $this->Price($product['price']);
			$products[$k]['price'] = $this->Price($product['price'], $product['discount']);
			
			//Распаковка характеристик
			//$products[$k]['types'] = unserialize($product['types']);
			
			//Ссылка
			$products[$k]['link'] = $this->Link($product['top'], $product['nav']?$product['nav']:$product['id']);
			
			//Сравнение
			$products[$k]['inCompare'] = false;
			if(isset($_SESSION['compare']) && is_array($_SESSION['compare'])) {
				if(isset($_SESSION['compare'][$product['id']])) {
					$products[$k]['inCompare'] = true;
				}
			}
			
			//Сниппет
			$products[$k]['snippet'] = $product['anons'];
		}
		
		//Бренды
		$brands_ids = array();
		if(isset($_GET['brands']) && is_array($_GET['brands'])) {
			$sBrands = $_GET['brands'];
		} else {
			$sBrands = array();
		}
		foreach ($products as $p) $brands_ids[$p['brand']] = true;
		$brands_ids = array_keys($brands_ids);
		$brands = array();
		if(!empty($brands_ids)) {
			$brands = $db->rows("
				SELECT * FROM `prefix_products_brands`
				WHERE
					`deleted` = 'N' AND
					`show` = 'Y' AND
					`id` IN (".implode(',', $brands_ids).")
				ORDER BY `order`
			", MYSQL_ASSOC);
			foreach ($brands as $k=>$v) {
				$brands[$k]['checked'] = false;
				if(!empty($sBrands)) {
					foreach ($sBrands as $bk=>$bv) {
						if($bv == $v['nav']) {
							$brands[$k]['checked'] = true;
							$additional_brand_title = $brands[$k]['name'];
							$this->productsFilter['brands'][] = $brands[$k]['id'];
						}
					}
				}
				$brands[$k]['link'] = getget(array('brands'=>array($v['nav']),'page'=>false));
			}
		}
		if(count($sBrands) > 1) $additional_brand_title = '';
		
		//Диапазон цен для слайдера
		$price_range = $db->query_first("SELECT MIN(`price`) AS `min`, MAX(`price`) AS `max` FROM `prefix_products` WHERE `deleted` = 'N' AND `show` = 'Y' AND `top` = ".(int)$this->topic['id']."");
		//echo "SELECT MIN(`price`) AS `min`, MAX(`price`) AS `max` FROM `prefix_products` WHERE `deleted` = 'N' AND `show` = 'Y' AND `top` = ".(int)$this->topic['id']."";
		$discounted_min = $db->query_first("SELECT `price` * (1 - `discount` / 100) AS `dprice` FROM `prefix_products` WHERE `deleted` = 'N' AND `show` = 'Y' AND `top` = ".(int)$this->topic['id']." ORDER BY `dprice` ASC LIMIT 1");
		$price_min = $this->Price($discounted_min['dprice']) - 100 ; //Скидка здесь уже содержится, пересчитывать ее не нужно
		$price_min = $price_min<0?0:$price_min;
		$price_max = $this->Price($price_range['max']) + 100;
		$price_max = $price_max<0?0:$price_max;
		$price_from = isset($_GET['PriceFromValue'])?(int)$_GET['PriceFromValue']:$price_min;
		$price_to = isset($_GET['PriceToValue'])?(int)$_GET['PriceToValue']:$price_max;
		$slider_vals = array(
			'min'	=> $price_min,
			'max'	=> $price_max,
			'from'	=> $price_from,
			'to'	=> $price_to,
			'step'	=> pow(10, abs(getSet('CatalogNano', 'price_round')))
		);
		if(isset($_GET['PriceFromValue']) && isset($_GET['PriceToValue'])) {
			$this->productsFilter['price'] = array(
				'form'	=> $price_from,
				'to'	=> $price_to
			);
		}
		
		//Фильтр товаров по брендам, цене и характеристикам
		$this->SelectionFilter($products);
		
		//Пэйджинг
		$products_paged = $this->Paging($products);
		$products = $products_paged['products'];
		$paging = $products_paged['rendered'];
		unset($products_paged);
		
		//Тайтл страницы (<head> <title>)
		$backpath = array_reverse($this->path);
		$head_title = array();
		foreach ($backpath as $i) {
			if($i['type'] == 'topic') {
				$head_title[] = $i['data']['name'];
			}
		}
		if(!empty($head_title)) $head_title[0] = $head_title[0].(empty($additional_brand_title)?'':' '.$additional_brand_title);
		$head_title = implode(' — ', $head_title);
		
		//Финальные приготовления
		$page_title = $this->topic['name'].(empty($additional_brand_title)?'':' '.$additional_brand_title);
		$brand_price_link = getget(array('page'=>false,'brands'=>false,'PriceFromValue'=>false,'PriceToValue'=>false), 1);
		//Подготавливаем картинки
		foreach ($products as $product) $product_ids[] = $product['id'];
		img()->PrepareImages('CatalogNano', $product_ids);
		
		return tpl('modules/'.__CLASS__.'/list', array(
			'head_title'	=> $head_title,
			'title'			=> $page_title,
			'brands'		=> $brands,
			'brand_price_link'	=> $brand_price_link,
			'slider_vals'	=> $slider_vals,
			
			'products'		=> $products,
			'paging'		=> $paging
		));
	}
	
	function CustomProductsList($products) {
		if(empty($products) || !is_array($products)) return false;
		
		$db = db();
		
		$topics = array();
		$brands = array();
		$ids = array();
		foreach ($products as $k=>$product) {
			//$products[$k]['types'] = unserialize($product['types']);
			$ids[] = $product['id'];
			$topics[$product['top']] = true;
			$brands[$product['brand']] = true;
		}
		$topics = array_keys($topics);
		$brands = array_keys($brands);
		
		if(empty($topics)) return false;
		
		img()->PrepareImages('CatalogNano', $ids, true);
		
		$ptopics = $db->rows("SELECT * FROM `prefix_products_topics` WHERE `deleted` = 'N' AND `show` = 'Y' AND `id` IN (".implode(',', $topics).")", MYSQLI_ASSOC);
		$topics = array();
		foreach ($ptopics as $topic) {
			$topic['link'] = $this->Link($topic['id']);
			$topics[$topic['id']] = $topic;
		}
		
		$pbrands = $db->rows("SELECT * FROM `prefix_products_brands` WHERE `deleted` = 'N' AND `show` = 'Y' AND `id` IN (".implode(',', $brands).")", MYSQLI_ASSOC);
		$brands = array();
		foreach ($pbrands as $brand) $brands[$brand['id']] = $brand;
		
		foreach ($products as $k=>$product) {
			if(!isset($topics[$product['top']])) continue;
			
			//Цена
			//$products[$k]['price'] = $this->Price($product['price']);
			$products[$k]['priceOld'] = $this->Price($product['price']);
			$products[$k]['price'] = $this->Price($product['price'], $product['discount']);
			
			//Распаковка характеристик
			//if(!is_array($products[$k]['types'])) $products[$k]['types'] = unserialize($product['types']);
			//if(!is_array($topics[$product['top']]['types'])) $topics[$product['top']]['types'] = unserialize($topics[$product['top']]['types']);
			
			//Ссылка
			$products[$k]['link'] = $this->Link($product['top'], $product['nav']?$product['nav']:$product['id']);
			
			//Топик
			$products[$k]['topic'] = $topics[$product['top']];
			
			//Бренд
			if(isset($brands[$product['brand']])) {
				$products[$k]['brand'] = $brands[$product['brand']];
			} else {
				$products[$k]['brand'] = false;
			}
			
			//Сниппет
			$products[$k]['snippet'] = $product['anons'];
		}
		
		//Пэйджинг (сохраняется в $this->paging_rendered)
		$products_paged = $this->Paging($products);
		$products = $products_paged['products'];
		
		return tpl('modules/'.__CLASS__.'/items', array(
			'products'	=> $products
		));
	}
	
	function CustomLittleProductsList($products) {
		if(empty($products) || !is_array($products)) return false;
		
		$db = db();
		
		$topics = array();
		$brands = array();
		$ids = array();
		foreach ($products as $k=>$product) {
			//$products[$k]['types'] = unserialize($product['types']);
			$ids[] = $product['id'];
			$topics[$product['top']] = true;
			$brands[$product['brand']] = true;
		}
		$topics = array_keys($topics);
		$brands = array_keys($brands);
		
		if(empty($topics)) return false;
		
		img()->PrepareImages('CatalogNano', $ids, true);
		
		$ptopics = $db->rows("SELECT * FROM `prefix_products_topics` WHERE `deleted` = 'N' AND `show` = 'Y' AND `id` IN (".implode(',', $topics).")", MYSQLI_ASSOC);
		$topics = array();
		foreach ($ptopics as $topic) {
			$topic['link'] = $this->Link($topic['id']);
			$topics[$topic['id']] = $topic;
		}
		
		$pbrands = $db->rows("SELECT * FROM `prefix_products_brands` WHERE `deleted` = 'N' AND `show` = 'Y' AND `id` IN (".implode(',', $brands).")", MYSQLI_ASSOC);
		$brands = array();
		foreach ($pbrands as $brand) $brands[$brand['id']] = $brand;
		
		foreach ($products as $k=>$product) {
			if(!isset($topics[$product['top']])) continue;
			
			//Цена
			//$products[$k]['price'] = $this->Price($product['price']);
			$products[$k]['priceOld'] = $this->Price($product['price']);
			$products[$k]['price'] = $this->Price($product['price'], $product['discount']);
			
			//Ссылка
			$products[$k]['link'] = $this->Link($product['top'], $product['nav']?$product['nav']:$product['id']);
			
			//Топик
			$products[$k]['topic'] = $topics[$product['top']];
			
			//Бренд
			if(isset($brands[$product['brand']])) {
				$products[$k]['brand'] = $brands[$product['brand']];
			} else {
				$products[$k]['brand'] = false;
			}
		}
		
		return tpl('modules/'.__CLASS__.'/littleItems', array(
			'products'	=> $products
		));
	}
	
	function FeaturedList($limit=0) {
		if($limit > 0) $sql_limit = 'LIMIT '.(int)$limit;
		else $sql_limit = '';
		$products = db()->rows("SELECT * FROM `prefix_products` WHERE `is_featured` = 'Y' AND `deleted` = 'N' AND `show` = 'Y' ORDER BY `rate` DESC $sql_limit", MYSQLI_ASSOC);
		
		return $this->CustomProductsList($products);
	}
	
	function Seen() {
		if(!isset($_SESSION['seen']) || empty($_SESSION['seen'])) page404();
		
		$ids = array_keys($_SESSION['seen']);
		
		$ids = array_reverse($ids);
		
		$prod = db()->rows("SELECT * FROM `prefix_products` WHERE `id` IN (".implode(',', $ids).") AND `deleted` = 'N' AND `show` = 'Y' ", MYSQLI_ASSOC);
		
		$productsById = array();
		foreach ($prod as $i) $productsById[$i['id']] = $i;
		unset($prod);
		
		$products = array();
		foreach ($ids as $id) $products[$id] = $productsById[$id];
		unset($productsById);
		
		$text = $this->CustomProductsList($products);
		$text .= $this->paging_rendered;
		
		return tpl('page', array(
			'title'	=> $this->alter_pages['seen']['name'],
			'text'	=> $text
		));
	}
	
	function SeenBlock($limit=0) {
		if(!isset($_SESSION['seen']) || empty($_SESSION['seen'])) return ;
		
		$ids = array_keys($_SESSION['seen']);
		
		$ids = array_reverse($ids);
		if($limit > 0) $ids = array_slice($ids, 0, $limit);
		
		$prod = db()->rows("SELECT * FROM `prefix_products` WHERE `id` IN (".implode(',', $ids).") AND `deleted` = 'N' AND `show` = 'Y'", MYSQLI_ASSOC);
		
		$productsById = array();
		foreach ($prod as $i) $productsById[$i['id']] = $i;
		unset($prod);
		
		$products = array();
		foreach ($ids as $id) $products[$id] = $productsById[$id];
		unset($productsById);
		
		return tpl('modules/'.__CLASS__.'/promoBlocks/seen', array(
			'littleProductsList' => $this->CustomLittleProductsList($products),
			'limit'	=> $limit,
			'count'	=> count($_SESSION['seen'])
		));
	}
	
	function AlsoBoughtBlock($limit=0) {
		if(!isset($this->product['relations']) || empty($this->product['relations'])) return ;
		
		if($limit > 0) $sql_limit = 'LIMIT '.(int)$limit;
		else $sql_limit = '';
		
		$products = db()->rows("SELECT * FROM `prefix_products` WHERE `id` IN (".$this->product['relations'].") AND `deleted` = 'N' AND `show` = 'Y' $sql_limit", MYSQLI_ASSOC);
		
		return tpl('modules/'.__CLASS__.'/promoBlocks/alsoBought', array(
			'littleProductsList' => $this->CustomLittleProductsList($products))
		);
	}
	
	
	
	/**
	 * Простой и незамысловатый поиск
	 */
	function Search() {
		$string = trim($_GET['string']);
		
		$error = '';
		if(empty($string)) $error = '<p>Пустой поисковый запрос, мы так ничего не найдем!</p>';
		if(mb_strlen($string) <= 1) $error = '<p>Очень короткий поисковый запрос, вы сами устанете искать то что нужно из всех совпадений!</p>';
		
		if(!empty($error)) return tpl('page', array('title' => $this->alter_pages['search']['name'],'text' => $error));
		
		$strings = explode(' ', $string);
		$highlight = array();
		
		//Убираем окончания
		$stemmer = new Lingua_Stem_Ru();
		foreach ($strings as $k=>$v) {
			$trimv = trim($v);
			$strings[$k] = $stemmer->stem_word($trimv);
			$highlight[] = $trimv;
		}
		
		//Окончательно фильтруем
		$strings = array_filter($strings);
		
		$like = array();
		foreach ($strings as $v) {
			$like[] = '(t.`name` LIKE \'%'.q($v).'%\' OR p.`name` LIKE \'%'.q($v).'%\' OR b.`name` LIKE \'%'.q($v).'%\')';
		}
		
		$products = db()->rows("
			SELECT p.* FROM `prefix_products` AS p
			LEFT JOIN `prefix_products_topics` AS t ON t.id = p.top
			LEFT JOIN `prefix_products_brands` AS b ON b.id = p.brand
			WHERE p.`deleted` = 'N' AND p.`show` = 'Y' AND (".implode(' AND ', $like).")
			ORDER BY `rate` DESC
		");
		
		if(count($products) == 0) {
			$products = db()->rows("
				SELECT p.* FROM `prefix_products` AS p
				LEFT JOIN `prefix_products_topics` AS t ON t.id = p.top
				LEFT JOIN `prefix_products_brands` AS b ON b.id = p.brand
				WHERE p.`deleted` = 'N' AND p.`show` = 'Y' AND (".implode(' OR ', $like).")
				ORDER BY `rate` DESC
			");
		}
		
		if(count($products) == 0) $error = '<p>Товары не найдены, попробуйте поискать с другим запросом!</p>';
		
		if(!empty($error)) return tpl('page', array('title' => $this->alter_pages['search']['name'],'text' => $error));
		
		$text = $this->CustomProductsList($products);
		/*
		foreach ($highlight as $v) {
			$text = str_replace($v, '<b>'.$v.'</b>', $text);
		}
		*/
		$text .= $this->paging_rendered;
		
		return tpl('page', array(
			'title'	=> $this->alter_pages['search']['name'],
			'text'	=> $text
		));
	}
	
	function SearchForExample() {
		$example = db()->query_first("
			SELECT p.`name` AS `pname`, b.`name` AS `bname` FROM `prefix_products` AS p
			LEFT JOIN `prefix_products_brands` AS b ON b.`id` = p.`brand`
			WHERE
				p.`deleted` = 'N' AND
				p.`show` = 'Y'
			ORDER BY RAND()
			LIMIT 1
		");
		
		$exampleString = trim($example['bname'].' '.$example['pname']);
		
		return $exampleString;
	}
	
	
	function Paging($products) {
		$products_count = count($products);
		$products_onpage = getSet('CatalogNano', 'onpage', 8);
		$pages_count = ceil($products_count/$products_onpage);
		if(isset($_GET['page'])) $page_current = abs((int)$_GET['page']);
		else $page_current = 1;
		$products_from = ($page_current-1)*$products_onpage;
		
		if($products_count <= $products_onpage) {
			$rendered = '';
		} else {
			$rendered = tpl('modules/'.__CLASS__.'/paging', array(
				'pages_count'	=> $pages_count,
				'page_current'	=> $page_current
			));
		}
		
		$this->paging_rendered = $rendered;
		
		return array(
			'products'	=> array_slice($products, $products_from, $products_onpage),
			'rendered'	=> $rendered
		);
	}
	
	function GetPaging() {
		if(isset($this->paging_rendered)) {
			return $this->paging_rendered;
		} else {
			return false;
		}
	}
	
	
	function SelectionFilter(&$products) {
		foreach ($products as $k=>$product) {
			//Бренды
			if(isset($this->productsFilter['brands']) && !in_array($product['brand'], $this->productsFilter['brands'])) {
				unset($products[$k]);
			}
			//Цена
			if(isset($this->productsFilter['price']) && ($product['price'] < $this->productsFilter['price']['form'] || $product['price'] > $this->productsFilter['price']['to'])) {
				unset($products[$k]);
			}
		}
	}
	
	
	function Product() {
		
		$db = db();
		
		//Добавление рейтинга товару и его группе
		if(!isset($_SESSION['seen'][$this->product['id']])) {
			$db->query("
				UPDATE `prefix_products` SET `rate` = `rate` + 1 WHERE `id` = ".$this->product['id'].";
				UPDATE `prefix_products_topics` SET `rate` = `rate` + 1 WHERE `id` = ".$this->topic['id'].";
			", true);
		}
		
		//Пишем в сессию что юзер видел этот товар
		if(!isset($_SESSION['seen'])) $_SESSION['seen'] = array();
		$_SESSION['seen'][$this->product['id']] = true;
		
		//Товар
		$product = $db->query_first("
			SELECT p.*, b.`name` AS `brand_name` FROM `prefix_products` AS p
			LEFT JOIN `prefix_products_brands` AS b ON b.`id` = p.`brand`
			WHERE p.`deleted` = 'N' AND p.`show` = 'Y' AND p.`id` = ".$this->product['id']."
		");
		
		//Топик
		$topic = $db->query_first("SELECT * FROM `prefix_products_topics` WHERE `id` = $product[top]");
		
		//Тайтл страницы (<head> <title>)
		$backpath = array_reverse($this->path);
		$head_title = array();
		$head_title[] = $product['brand_name'].' '.$product['name'];
		foreach ($backpath as $i) {
			if($i['type'] == 'topic') {
				$head_title[] = $i['data']['name'];
			}
		}
		$head_title = implode(' — ', $head_title);
		
		//Цена
		//$product['price'] = $this->Price($product['price']);
		$product['priceOld'] = $this->Price($product['price']);
		$product['price'] = $this->Price($product['price'], $product['discount']);
		
		//В корзине ль
		$product['inbasket'] = false;
		if(isset($_SESSION['basket'][$product['id']]) && $_SESSION['basket'][$product['id']] != 0) {
			$product['inbasket'] = $_SESSION['basket'][$product['id']];
		}
		$product['inbaskethint'] = $this->ProductInBasketHint($product['id']);
		
		//Финальные приготовления
		$page_title = $product['brand_name'].' '.$product['name'];
		
		return tpl('modules/'.__CLASS__.'/one', array(
			'head_title'	=> $head_title,
			'title'			=> $page_title,
			'product'		=> $product
		));
	}
	
	public function ProductInBasketHint($id) {
		$id = abs((int)$id);
		$product = db()->query_first("
			SELECT p.*, b.name AS `brand_name` FROM `prefix_products` AS p
			LEFT JOIN `prefix_products_brands` AS b ON b.`id` = p.`brand`
			WHERE p.`id` = $id
		");
		
		if(empty($product)) return '';
		
		$text = $product['brand_name'].' '.$product['name'].' в корзине';
		$text .= (isset($_SESSION['basket'][$product['id']])&&$_SESSION['basket'][$product['id']]>1?' ('.$_SESSION['basket'][$product['id']].' '.plural($_SESSION['basket'][$product['id']], 'штук', 'штука', 'штуки').')':'').', ';
		$text .= 'Вы можете <a href="'.linkByModule('Basket').'">оформить заказ</a> или <a href="'.$this->Link($product['top']).'">продолжить покупки</a>. ';
		$text .= !empty($product['relations'])?'Обратите внимание, что еще покупают с этим товаром. ':'';
		
		return $text;
	}
	
	private $currency;
	function Price($price, $discount=0) {
		if($price > 0) {
			//Расчет курса (выполняется один раз!)
			if(empty($this->currency)) {
				$currencies = unserialize(getVar('currency'));
				$selectedCurrency = getSet('CatalogNano', 'inner_currency');
				if($currencies && isset($currencies[$selectedCurrency]) && $currencies[$selectedCurrency] > 0)	{
					$this->currency = $currencies[$selectedCurrency];
				} else $this->currency = 1;
				
				//Надбавка к конвертации
				if($this->currency > 1) {
					$this->currency = $this->currency * ( 1 + (getSet('CatalogNano', 'currency_margin') / 100) );
				}
			}
			//Конвертация цены товара от валюты
			$price = $price * $this->currency;
			
			//Расчет скидки на товар (акции и подобное)
			$price = $price * (1 - $discount / 100);
			
			//Округление
			$price = round($price, getSet('CatalogNano', 'price_round'));
		}
		
		return $price;
	}
	
	
}

?>