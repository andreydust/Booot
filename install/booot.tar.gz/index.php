<?php
include('system/loading.php');

timegen('allsite');

$GLOBALS['data'] = new SimpleData();

include(DIR.'/system/starter.php');

timegen_result();

?>